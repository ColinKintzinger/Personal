
public class message {

	public static void main(String[] args) {
		System.out.println("/////////////////////////");
		System.out.println("|| CS-144 Java Program ||");
		System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
	}

}

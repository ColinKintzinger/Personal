
public class spiky {

	public static void main(String[] args) {
		System.out.println("\t  \\/");
		System.out.println("\t \\\\//");
		System.out.println("\t\\\\\\///");
		System.out.println("\t///\\\\\\");
		System.out.println("\t //\\\\");
		System.out.println("\t  /\\");
	}

}

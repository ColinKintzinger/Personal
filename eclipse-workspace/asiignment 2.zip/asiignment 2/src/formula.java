
public class formula {

	public static void main(String[] args) {
		double a=2;
		double x=4.6;
		double z=5.1;
		double equasion=a*x+z;
		System.out.println(equasion);

	}

}
